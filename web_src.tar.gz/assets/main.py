"""Browser entry point: pygbag runs this, and the game loop hands control back to the page every frame."""
import asyncio

import pygame

import casino


async def main():
    pygame.init()
    screen = pygame.display.set_mode((casino.W, casino.H))
    screen.fill((10, 8, 12))
    text = pygame.font.Font(None, 54).render("Shuffling the decks...", True, (230, 190, 90))
    screen.blit(text, text.get_rect(center=(casino.W // 2, casino.H // 2)))
    pygame.display.flip()
    await asyncio.sleep(0.2)             # let the page show that before the (slow) start-up
    app = casino.App()
    for _ in app.frames():
        await asyncio.sleep(0)

asyncio.run(main())
